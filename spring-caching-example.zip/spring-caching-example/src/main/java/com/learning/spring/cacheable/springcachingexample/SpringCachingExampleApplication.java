package com.learning.spring.cacheable.springcachingexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCachingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCachingExampleApplication.class, args);
	}

}
