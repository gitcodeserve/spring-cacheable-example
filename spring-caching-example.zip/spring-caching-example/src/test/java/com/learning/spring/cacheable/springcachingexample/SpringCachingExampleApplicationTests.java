package com.learning.spring.cacheable.springcachingexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCachingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
